<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Splash</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" type="text/css" href="./assets/css/homepage.css">
	</head>
	<body>
		<div class="landing_page">
			<div class="landing_page_animation">
			</div>
		</div>
		<div class="page_container">
			<header>
				<h1>FlipSide</h1>
				<button class="menu">
					<span class="line _top"></span>
					<span class="line _middle"></span>
					<span class="line _bottom"></span>
				</button>
			</header>
		</div>

		<div class="menu_box">
			<div class="menu_items">
				<div class="menu_linkbox">
					<div class="menu_link_verticalbox">
						<ul>
							<li><a data-open="about_us">About Us</a></li>
							<li><a data-open="services">Services</a></li>
							<li><a data-open="contact">Contact</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="menu_content body_data">
			<div class="menu_contentbox body_databox">
				<div class="menu_center_align body_center_align">
					<div data-container="subone_data" class="body_boxone">
						<p>Yo 1</p>
					</div>
					<div data-container="subtwo_data" class="body_boxone">
						<p>Yo 2</p>
					</div>
					<div data-container="subthree_data" class="body_boxone">
						<p>Yo 3</p>
					</div>
					<div data-container="subfour_data" class="body_boxone">
						<p>Yo 4</p>
					</div>
					<div data-container="about_us" class="menu_inner menu_about">
						<p>Hello</p>
					</div>
					<div data-container="services" class="menu_inner menu_services">
						<p>BYE</p>	
					</div>	
					<div data-container="contact" class="menu_inner menu_contact">
						<div class="div_center">
							<form name="frmContact" action="" method="POST">
								<div class="form_group">
									<h1>Contact</h1>
								</div>
								<div class="form_group">
									<input type="text" id= "user_name" name="user_name" class="form_input" data-input required>
									<label for="user_name" class="form_label">Name<span class="required"> *</span></label>
								</div>
								<div class="form_group">
									<input type="text" id="" name="email_address" class="form_input" data-input required>
									<label for="email_address" class="form_label">Email Address<span class="required"> *</span></label>
								</div>
								<div class="form_group">
									<input type="text" id="" name="phone_number" class="form_input" data-input required>
									<label for="phone_number" class="form_label">Phone Number<span class="required"> *</span></label>
								</div>
								<div class="form_group">
									<textarea id="" name="user_message" class="form_input message" data-input required></textarea>
									<label for="user_message" class="form_label">Message<span class="required"> *</span></label>
								</div>
								<div class="form_group">
									<input onclick="javascript: page.fnFieldSubmit();" type="button" name="submit" id="submit" value="Submit" class="btn_primary">
									<!-- <button name="btn_submit" class="btn_primary" value="submit">Submit</button> -->
								</div>
							</form>
						</div>
					</div>									
				</div>
			</div>
		</div>
		<div class="box owl-carousel">
			<div class="sub_box _one">
				<a data-open="subone_data">
					<div class="box_table">
						<div class="inner_table">
							<h2>01</h2>
							<h3>Box 1 SubHeader</h3>
							<h4>Box 1 Bottom SubHeader</h4>	
							<img class="img_background" src="./assets/img/owl.SVG" alt="owl">
						</div>
					</div>
				</a>
			</div>
			<div class="sub_box _two">
				<a data-open="subtwo_data">
					<div class="box_table">
						<div class="inner_table">
							<h2>02</h2>
							<h3>Box 2 SubHeader</h3>
							<h4>Box 2 Bottom SubHeader</h4>
							<img class="img_background" src="./assets/img/owl.SVG" alt="">
						</div>
					</div>
				</a>
			</div>
			<div class="sub_box _three">
				<a data-open="subthree_data">
					<div class="box_table">
						<div class="inner_table">
							<h2>03</h2>
							<h3>Box 3 SubHeader</h3>
							<h4>Box 3 Bottom SubHeader</h4>	
							<img class="img_background" src="./assets/img/owl.SVG" alt="">
						</div>
					</div>
				</a>
			</div>	
			<div class="sub_box _four">
				<a data-open="subfour_data">
					<div class="box_table">
						<div class="inner_table">
							<h2>04</h2>
							<h3>Box 4 SubHeader</h3>
							<h4>Box 4 Bottom SubHeader</h4>	
							<img class="img_background" src="./assets/img/owl.SVG" alt="">
						</div>
					</div>
				</a>
			</div>	
		</div>
		<script src="/assets/js/home_page.js"></script>
		<script>
			$('.owl-carousel').owlCarousel({
			    loop 		:true,
			    margin		:0,
			    nav 		:true,
			    smartSpeed  : 700,
			    responsive:{
			        0:{
			            items:1
			        },
			        600:{
			            items:3
			        },
			        1000:{
			            items:3
			        }
			    }
			})
		</script>
	</body>
</html>