<!DOCTYPE html>
<html>
<head>
	<title>Thank You</title>
</head>
<body>
<h1>Thank You</h1>
</body>
</html>