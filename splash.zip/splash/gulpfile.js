/* Common plugIns*/
var gulp      		=   require('gulp'),
	watch 			=	require('gulp-watch'),
	concat 			= 	require('gulp-concat'),
	uglify 			= 	require('gulp-uglify'),
	rev 			= 	require('gulp-rev'),
	plumber			=	require('gulp-plumber'),
	livereload 		= 	require('gulp-livereload'),
	del 			= 	require('del'),
	vinylPaths 		= 	require('vinyl-paths');

/* PlugIns for SVG sprite */
var	svgSprite     	=   require('gulp-svg-sprite'),
	modf          	=   require("gulp-attr-remover"),
	stripDebug		=	require('gulp-strip-debug'),
	svgFiles      	=   ['common']; // Create folder with respect to your file name insite svgs folder

/* PlugIns for Less to CSS */
var less 					=	require('gulp-less'),
	path 					=	require('path'),
	minifyCSS 				=	require('gulp-minify-css'),
	LessPluginCleanCSS 		=	require('less-plugin-clean-css'),
    LessPluginAutoPrefix 	=	require('less-plugin-autoprefix'),
    cleancss 				=	new LessPluginCleanCSS({ advanced: true }),
    autoprefix 				=	new LessPluginAutoPrefix({ browsers: ["last 2 versions"] });
	lessFiles      			=   ['homepage']; // Create folder with respect to your file name insite svgs folder

/* This is to remove the fill attribute */
function predicate(elem) {
	"use strict";
	if (!/^((ftp|rtsp|mms):)?\/\//.test(elem.attr('fill'))) {
		return true;
	}
	return false;
}

/* SVG sprite task */
gulp.task('sprite', function() {
	svgFiles.forEach(function(svgFiles){
		var tsk = gulp.src('./style/svg/'+svgFiles+'/*.svg')
					.pipe(svgSprite(
						config = {
								mode : {
									symbol : {
										dest : '.',
										sprite : svgFiles+'-icons.svg',
									}
								},
								shape : {
									id : {
										generator: 'icon-%s'
									}
								}
							}
						));
					tsk.pipe(gulp.dest('./assets/icon/'));
	})
});

/* Less task */
// gulp.task('less', function () {
// 	lessFiles.forEach(function(lessFiles){
// 		gulp.src('./styles/less/'+lessFiles+'.less')
// 		.pipe(less({
// 			paths: [ path.join(__dirname, 'less', 'includes') ]
// 		}))
// 		// .pipe(minifyCSS())
// 		.pipe(gulp.dest('./public/css'))
// 		.pipe(livereload());
// 	})
// });

/* Less task */

/*======================================================
=            LESS - Minification & Revision            =
======================================================*/

/*==========  DEVELOPMENT  =======s===*/

if (typeof(process.env.NODE_ENV) === "undefined" || process.env.NODE_ENV !== "PRODUCTION") {
	gulp.task('less', function () {
		return gulp.src(allLessFiles())
		.pipe(less({
			paths: [ path.join(__dirname, 'less', 'includes') ]
		}))
		.pipe(minifyCSS({timeout: 20}))
		.pipe(gulp.dest('./assets/css/'))
	});
}


/*
	########################################
		Gulp for JS & CSS Compress and concat
	########################################
*/

/* To be moved to top */
var output_path = {
	"js"	:	"./assets/js",
	"css"	:	"./css",
	"icons"	:	"./icons",
	"temp"  :   "temp"
};

var js_source_path 				= {};
js_source_path["home_page.js"] 	= [
	'script/plugins/jquery.min.js',
	'script/plugins/owl.carousel.js',
	'script/page/home.js'
];

function allJSFiles(){
	var _files = [];
	console.log('concatenating JS files');
	//console.log(js_source_path);
	Object.keys(js_source_path).forEach(function(key) {
		//console.log(key);
		js_source_path[key].forEach(function(file) {
			//console.log(file);
			_files.push(file);
		});
	});
	//console.log(_files);
	return _files;
}

function allLessFiles() {
	var _files = [];
	lessFiles.forEach(function(file) {
		_files.push('./style/less/'+file+'.less');
	});

	console.log(_files);

	return _files;
}


/*=========================================================
=            Building & Concatenating JS Files            =
=========================================================*/

/* Creating tasks for concatenating all JS files */
if (typeof(process.env.NODE_ENV) === "undefined" || process.env.NODE_ENV !== "PRODUCTION") {
	Object.keys(js_source_path).forEach(function(newFile){
		//console.log(js_source_path[newFile])
		gulp.task(newFile, function() {
			return gulp.src(js_source_path[newFile])
			.pipe(concat(newFile))
			.pipe(uglify())
			//.pipe(stripDebug())
			.pipe(gulp.dest(output_path.js));
		});

	});

} else if (typeof(process.env.NODE_ENV) !== "undefined" && process.env.NODE_ENV == "PRODUCTION") {
	Object.keys(js_source_path).forEach(function(newFile){
		//console.log(js_source_path[newFile])
		gulp.task(newFile, function() {
			return gulp.src(js_source_path[newFile])
			.pipe(concat(newFile))
			.pipe(uglify())
			.pipe(stripDebug())
			.pipe(gulp.dest(output_path.temp));
		});
	});
}


/* Fetching list of concatenated filenames to add revision */

var dependencies = function() {
	var _files = ['less'];
	Object.keys(js_source_path).forEach(function(newFile) {
		_files.push(newFile);
	});

	return _files;
}();

console.log(dependencies);

/*-----  End of Building & Concatenating JS Files  ------*/


/*=============================================
=            Cleanup Public folder            =
=============================================*/

/* Cleanup public/js & public/css folder to avoid multiple revisions
of the same file */

gulp.task('cleanup', function(cb) {
	//return gulp.src([output_path.js+'/*', output_path.css+'/*'])
	//.pipe(vinylPaths(del))
	//.pipe(gulp.dest('.'))
	console.log('cleaning up');

	del([output_path.js+'/*', output_path.css+'/*', './rev-manifest.json'], cb)
});


/*-----  End of Cleanup Public folder  ------*/




/*==========================================================
=            GULP REV for JS File Versioning               =
==========================================================*/

/* We provide the concatenated filenames as task dependencies
so rev makes sure that they are concatenated again before
applying a revision */

/*==========  DEVELOPMENT  ==========*/

if (typeof(process.env.NODE_ENV) === "undefined" || process.env.NODE_ENV !== "PRODUCTION") {
	gulp.task('rev', dependencies, function () {
		return gulp.src(output_path.js+'/*')
	});
}


/*==========  PRODUCTION  ==========*/

if (typeof(process.env.NODE_ENV) !== "undefined" && process.env.NODE_ENV == "PRODUCTION") {
	gulp.task('rev', dependencies, function () {
		return gulp.src(output_path.temp+'/*')
		.pipe(vinylPaths(del))
		.pipe(rev())
		.pipe(gulp.dest(output_path.js))
		.pipe(rev.manifest(__dirname + "/rev-manifest.json", {merge: true }))
		.pipe(gulp.dest('.'))
	});
}

/*-----  End of GULP REV for File Versioning  ------*/


/*============================================================
=            Default Tasks for Production & Dev             =
============================================================*/


gulp.task('default', ['sprite', 'rev']);


/*-----  End of Default Task - Common for Dev & Prod  ------*/



if (typeof(process.env.NODE_ENV) !== "undefined" && process.env.NODE_ENV == "PRODUCTION") {

} else {

	/*==========  Watch Task - Defined only for dev environment  ==========*/

	//Watch on change JS & CSS files
	gulp.task('watch', function () {
		// livereload.listen();
	    Object.keys(js_source_path).forEach(function (fileName) {
	    	gulp.watch(js_source_path[fileName], {
		        maxListeners: 150
		    }, [fileName]);
	    });

		gulp.watch('./style/less/**/*.less', ['less']);  // Watch all the .less files, then run the less task
	});

}