var gPagestate;
$(document).ready(function(){
	$( "._one" ).hover(function() {
	    	$('h1').css("color","white");
		}, function() {
	    	$('h1').css("color","black");
	  	}
	);

	$(".sub_box").hover(function() {
		$(".sub_box").removeClass("_active");
    	$(this).addClass("_active");
	});

//Triggering menu events
   	$(".menu").click(function() {
    	
    	if(!gPagestate){
    		$(".menu_box").show();
			$(this).addClass('_active');
			$('h1').css("color","white");
			gPagestate = 1;
    	} else {
			if(gPagestate == 1){
				$(".menu_box").hide();
				$(this).removeClass("_active");
				$('h1').css("color","black");
				gPagestate = undefined;
			} else {
				gPagestate = 1;
				$(".menu_box").show();
				$(".menu_content").hide();
				$(this).addClass('_active');
				$('h1').css("color","white");
			}
    	}
	});
    $(".menu_link_verticalbox a").on("click", function(){
    	gPagestate = 2;
    	var _elm = $(this).attr("data-open");
    	$("[data-container]").hide();
    	$("[data-container='"+ _elm +"']").show();
    	$(this).parents(".menu_box").hide();
    	$("[data-container='"+ _elm +"']").parents(".menu_content").show();
    });

	$(".sub_box").click(function() {
			$(".body_data").show();
			$(this).addClass('_change');
			$('h1').css("color","white");
	});

    $(".sub_box a").on("click", function(){
    	var _open = $(this).attr("data-open");
    	$("[data-container]").hide();
    	$("[data-container='"+ _open +"']").show();
    	$(this).parents(".sub_box").hide();
    	$("[data-container='"+ _open +"']").parents(".body_data").show();
    });
});