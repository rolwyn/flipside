///////////////////////////////////
// Global Object to bind functions
///////////////////////////////////

var GSH = {
	Misc 		: {},
	Modal 		: {},
	Validate 	: {},
	UserId 		: "",
	UserInfo 	: "",
	API 		: "./api.php",
	AdminAPI 	: "/admin/api/",
    AjaxURL     : "./ajax.php",
    AjaxURL     : "./ajax.php",
	AdminAjax 	: "/admin/ajax.php",
    ImagePath   : "/assets/img/",
    ProperyLink : "properties",
    RupeeIcon   : "&#8377",
    ThemeColor  : "#63c8c4",
    SubColor  	: "#ff7a5b",
    ButtonTxt   : "Belong Here",
    HelpLine    : "8080 900 300",
    Device      : "Desktop",
    isLoggedIn  : "No",
    Protocol    : window.location.protocol,
    Host	    : window.location.hostname,
    Connection 	: ""
};
var navNot = "";

(function($) {
	$.fn.modal = function() {

		GSH.Modal.currentModal 	= 	null;

		var overlay 		=	$(".modal-wrapper .__overlay");
		var container 		=  	$(".modal-wrapper");
		var element 		= 	$(".modal-wrapper .modal");
		var animateClass	=	'_showmodal';
		var dismiss 		= 	$('.__dismiss');

		$('[data-modal]').click(function(){
			var modalId = $(this).attr('data-modal');
			GSH.Modal.fnShowModal(modalId);
		});

		overlay.click(function(){
			GSH.Modal.fnHideModal();
		});

		dismiss.click(function(){
			GSH.Modal.fnHideModal();
		});

		/* SHOW MODALS ON PAGE */
		GSH.Modal.fnShowModal = function(modalId) {
			var currScrollPos = $(document).scrollTop();

			if(GSH.Modal.currentModal != null){
				GSH.Modal.currentModal.removeClass(animateClass);
	            GSH.Modal.currentModal.hide();
			}
			GSH.Modal.currentModal 	= $('#'+modalId);
			container.show();
			overlay.show();
			GSH.Modal.currentModal.show();
            GSH.Modal.currentModal.addClass(animateClass);
            $("body").addClass("_fixed");

			/* Reset all the input fields on modal */
			$(GSH.Modal.currentModal).find('input[type=text],input[type=email],input[type=number],textarea').val('');

			/* Adding Spot focus on the first input element */
			$focusElem = $(GSH.Modal.currentModal).find('input[type=text],input[type=email],input[type=number],textarea,select').filter(':visible:first')
			if($focusElem != "") {
				setTimeout(function(){
					$focusElem.focus();
				}, 200);
			}
		}

		/* HIDE MODALS ON PAGE */
		GSH.Modal.fnHideModal = function(){

			if(typeof GSH.Modal.currentModal !== "undefined" && GSH.Modal.currentModal != null) {
				container.hide();
				overlay.hide();
				GSH.Modal.currentModal.removeClass(animateClass);
	            GSH.Modal.currentModal.hide();
				GSH.Modal.currentModal = null;
                $("body").removeClass("_fixed");
			}
		}
	}
}(jQuery));

GSH.Misc.fnLogout = function() {
    try {

    	var id 	= GSH.Misc.fnGVal({ key: 'user_id' , data : keep.get({ name : 'ld' }) });
    	var sid = GSH.Misc.fnGVal({ key: 'sid' , data : keep.get({ name : 'ld' }) });

    	var apiURL = location.protocol + "//" + location.host + '/admin/api/';

    	GSH.Misc.fnBusy(1, {message : "Logging you out..."});

    	GSH.Misc.fnAjax({
    		url : apiURL,
    		data : {
    			cmd : 'LOGOUT',
    			user_id : id,
    			session_id : sid
    		}, 
    		success : function(data) {
    			
    			data = JSON.parse(data);

    			GSH.isLoggedIn = "No";

    			keep.del({ name : 'ld' });
    			window.location = location.protocol + "//" + location.host + '/admin/';

    		},
    		error : function (xhr, testStatus, err) {
    			keep.del({ name : 'ld' });
    			window.location = location.protocol + "//" + location.host + '/admin/';
    		}
    	});

    } catch (e) {
        GSH.Misc.fnErr({
            fnName: "GSH.Misc.fnLogout",
            err: e
        });
    }
}

GSH.Misc.fnGetCRMUserInfo = function() {
    try {
    	GSH.isLoggedIn = "Yes";

    	var apiURL 	= location.protocol + "//" + location.host + '/admin/api/';
    	var id 		= GSH.Misc.fnGVal({ key: 'user_id' , data : keep.get({ name : 'ld' }) });
    	var sid 	= GSH.Misc.fnGVal({ key: 'sid' , data : keep.get({ name : 'ld' }) });

    	GSH.Misc.fnAjax({
    		url : apiURL,
    		data : {
    			cmd 		: 'GETUSERINFO',
    			user_id 	: id,
    			session_id 	: sid
    		}, 
    		success : function(data) {

    			data = JSON.parse(data);

    			if(data.status == "true"){
    				GSH.UserInfo        = data;
                    var tempUserInfo    = GSH.UserInfo.data.customData;
                    GSH.UserInfo        = {};
                    GSH.Misc.fnMakeUserInfoGlobal(tempUserInfo);
    				keep.set({ name : 'ld', value : tempUserInfo, sess : false });
    			}

    		},
    		error : function (xhr, testStatus, err) {
    			
    		}
    	});

    } catch (e) {
        GSH.Misc.fnErr({
            fnName: "GSH.Misc.fnGetCRMUserInfo",
            err: e
        });
    }
}

GSH.Misc.fnAjax = function(params) {
	try {

		var url 		= ( typeof params.url 		!== "undefined" && params.url 	   != "" )   ? params.url 		: 	''		;
		var data 		= ( typeof params.data 		!== "undefined" && params.data 	   != "" )	 ? params.data 		: 	''		;
		var type 		= ( typeof params.type 		!== "undefined" && params.type 	   != "" )	 ? params.type 		: 	'POST'	;
		var dataType 	= ( typeof params.dataType 	!== "undefined" && params.dataType != "" )	 ? params.dataType 	: 	''	;
		var success		= ( typeof params.success	!==	"undefined"	&& params.success  != "" )   ? params.success	:	false	;
		var error		= ( typeof params.error		!==	"undefined"	&& params.error    != "" )   ? params.error		:	false	;
		var async 		= ( typeof params.async		!==	"undefined"	&& params.async    != "" )   ? params.async		:	true  	;


		$.ajax({
            url 	: url, 
            data    : data,
            type    : type,
            dataType: dataType,
            async 	: async,
            timeout : 1000 * 60 * 5,
            success : function(data) {
                if(success) {
					success(data);
				}
            },
            error   : function (xhr, status, err) {
            	if (xhr.status == 0) {
                    return;
                } else{
					error(xhr, status, err);
					return;
				}
			}
        });

	} catch (e) {
		GSH.Misc.fnErr({ fnName: 'GSH.Misc.fnAjax', fnParams: params,  err: e });
	}
}

GSH.Misc.fnGenerateOtp = function(params, callback) {
    try {

        GSH.Misc.fnBusy(1, {message : "Generating..."});
        // console.log("GSH.Misc.fnGenerateOtp");
        GSH.Misc.fnAjax({
            url : GSH.AdminAjax,
            data : {
                cmd         : "GENERATEOTP",
                mobile      : params.mobile,
                invoice_id  : params.invoice_id,
                appcode     : GSH.AppCode
            },
            success : function(response) {
                GSH.Misc.fnBusy(0);
                var resp = JSON.parse(response);
                callback(null, resp);
            },
            error : function(xhr, status, err) {
                GSH.Misc.fnBusy(0);
                callback(err, null);   
            }       
        });

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGenerateOtp", fnParams: params, err: e });
    }
}

GSH.Misc.fnSendSMS = function(params, callback) {
    try {
        GSH.Misc.fnBusyMsg(1, "Sending SMS...");

        var _template       = ( typeof params.template       !== "undefined" && params.template      != "" )   ? params.template         :   '';
        var _mobile         = ( typeof params.mobile         !== "undefined" && params.mobile        != "" )   ? params.mobile           :   '';
        var arrField        = ( typeof params.fields         !== "undefined" && params.fields        != "" )   ? params.fields           :   '';

        var objSend = {
            "cmd"             : "SENDMESSAGE",
            "template"        : _template,
            "mobile"          : _mobile
        };

        objSend.data = arrField;

        GSH.Misc.fnAjax({
            url : GSH.AdminAjax,
            data : objSend,
            success : function(response) {
                GSH.Misc.fnBusyMsg(0);
                var resp = JSON.parse(response);
                GSH.Misc.fnAndroidErr(resp.blnStatus);
                console.log(resp);
                callback(null, resp);
            },
            error : function(xhr, status, err) {
                GSH.Misc.fnBusyMsg(0);
                callback(err, null);   
            }       
        });

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnSendSMS", fnParams: params, err: e });
    }
}

GSH.Misc.fnSendOTPEmail = function(params, callback) {
    try {
        GSH.Misc.fnBusyMsg(1, "Sending OTP on email...");

        var _type           = ( typeof params.type              !== "undefined" && params.type          != "" )   ? params.type             :   '';
        var _email          = ( typeof params.email             !== "undefined" && params.email         != "" )   ? params.email            :   '';
        var arrField        = ( typeof params.fields            !== "undefined" && params.fields        != "" )   ? params.fields           :   '';

        var objSend = {
            "cmd"               : "GENERATEOTPONEMAIL",
            "type"              : _type
        };

        objSend.data = arrField;

        GSH.Misc.fnAjax({
            url     : GSH.AdminAjax,
            data    : objSend,
            success : function(response) {
                GSH.Misc.fnBusyMsg(0);
                var resp = JSON.parse(response);
                if(resp.status == "true"){
                    GSH.Misc.fnAndroidErr(resp.data.DisplayMessage);
                    callback(null, resp);
                } else
                    GSH.Misc.fnAndroidErr(resp.error.DisplayMessage);
            },
            error : function(xhr, status, err) {
                GSH.Misc.fnBusyMsg(0);
                callback(err, null);   
            }       
        });

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnSendOTPEmail", fnParams: params, err: e });
    }
}

GSH.Misc.fnSendEmail = function(params, callback) {
    try {
    	var _from 		= $("#inpSendFrom").val();
    	var _to 		= $("#inpSendTo").val();
    	var _msg 		= $("#inpSendBody").val();
    	var _subject 	= $("#inpSendSubject").val();

        if(_from == "") {
            GSH.Misc.fnAndroidErr("Sender is empty");
            return;
        }

        if(_to == "") {
            GSH.Misc.fnAndroidErr("Receiver is empty");
            return;
        }

        if(!GSH.Validate.comments(_subject)) {
            GSH.Misc.fnAndroidErr("subject line is not valid");
            return;
        }

        if(_msg == "") {
            GSH.Misc.fnAndroidErr("Message is empty");
            return;
        }

        $("#mdSendEmail ._field-btn a").addClass("_loading");
        
        GSH.Misc.fnAjax({
            url 	: GSH.AdminAPI,
            data 	: {
                cmd 	: "SENDEMAIL",
                from 	: _from,
                to 		: _to,
                body 	: _msg,
                subject : _subject
            },
            success : function(data) {
                GSH.Misc.fnBusy(0);
                data = JSON.parse(data);
                $("#mdSendEmail ._field-btn a").removeClass("_loading");
                
                if(data.status == "true"){
                	GSH.Modal.fnHideModal();
                	GSH.Misc.fnAndroidErr(data.data.DisplayMessage);
                } else
                	GSH.Misc.fnAndroidErr(data.error.DisplayMessage);

                if(!ledger)
                	window.location.reload();
                
            },
            error : function(xhr, status, err) {
                GSH.Misc.fnBusy(0);
                callback(err, null);   
            }       
        });

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnSendEmail", fnParams: params, err: e });
    }
}

GSH.Misc.fnVerifyOtp = function(params, callback) {
    try {

        GSH.Misc.fnBusy(1, {message : "Verifying OTP..."});

        GSH.Misc.fnAjax({
            url : location.protocol + "//" + location.host + '/admin/ajax',
            data : {
                cmd     : "VERIFYOTP",
                mobile  : params.mobile,
                OTP     : params.otp,
                isAdmin : params.isAdmin,
                appcode : GSH.AppCode
            },
            success : function(res) {
                GSH.Misc.fnBusy(0);
                res = JSON.parse(res);
                callback(null,res);
            },
            error : function(xhr, status, err) {
                GSH.Misc.fnBusy(0);
                callback(err,null);
            }       
        });

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnVerifyOtp", fnParams: params, err: e });
    }
}

GSH.Misc.fnGetHours = function(date, newdate){
    try {
        var hours = Math.abs(date - newdate) / 36e5;
        return parseInt(hours);
    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGetHours", err: e });
    }
}

GSH.Misc.fnGetTime = function(date){
    try {
    	function addZero(i) {
		    if (i < 10) {
		        i = "0" + i;
		    }
		    return i;
		}
        var d = new Date(date);
		var h = addZero(d.getHours());
		var m = addZero(d.getMinutes());
		var s = addZero(d.getSeconds());

        return h + ":" + m;

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGetTime", err: e });
    }
}

GSH.Misc.fnAndroidErr = function(text) {
    try {

        if($(".android-error").length < 1){
            var _strHtml = '<div class="android-error"></div>';
            $('body').append(_strHtml);
        }

        $(".android-error").html('<p>'+ text +'</p>');

        setTimeout(function(){
            $(".android-error").addClass("_show");
        }, 200);

        setTimeout(function(){
            $(".android-error").removeClass("_show");
        }, 5000);

    } catch(e) {
        console.log("In Error function");
    }
}

GSH.Misc.fnGetDays = function(date, newdate){
    try {
		var oneDay 		= 24*60*60*1000; // hours*minutes*seconds*milliseconds
		var firstDate 	= new Date(date);
		var secondDate 	= new Date(newdate);

		var diffDays = Math.round(Math.abs((firstDate.getTime() - secondDate.getTime())/(oneDay)));
		return diffDays;
    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGetDays", err: e });
    }
}

GSH.Misc.fnGetPropertDays = function(date, newdate){
    try {
        var oneDay      = 24*60*60*1000; // hours*minutes*seconds*milliseconds
        var firstDate   = new Date(date);
        var secondDate  = new Date(newdate);

        var diffDays = Math.round((firstDate.getTime() - secondDate.getTime())/(oneDay));
        return diffDays;
    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGetDays", err: e });
    }
}

GSH.Misc.fnCheckPastDate = function(date){
    try {
       var _date    = date;
       var _date    = new Date(_date);
       var now      = new Date();
       if(_date < now)
            return true;
        else
            return false;

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnCheckPastDate", err: e });
    }
}

GSH.Misc.fnSortArray = function(arr, by){
    try {

        arr = arr.sort(function(a, b) {
            return parseFloat(a[by]) - parseFloat(b[[by]]);
        });
        arr = $(arr).get().reverse();
        return arr;
        
    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnSortArray", err: e });
    }
}

GSH.Misc.fnGetMonths = function(from, to){
	try {
		var _from 	= new Date(from);
        var _to     = new Date(to);
        var _months = (_from.getFullYear() - _to.getFullYear()) * 12;
        _months     += _from.getMonth() - _to.getMonth();
        if (_from.getDate() < _to.getDate())
            _months--;
        
        return Math.abs(_months);
	} catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGetMonths", err: e });
    }
}

GSH.Misc.fnTextScroll = function(elm){
    try {

		$(elm).mouseover(function() {
		    $(this).removeClass("ellipsis");
		    var maxscroll = $(this).width();
		    var speed = maxscroll * 15;
		    $(this).animate({
		        scrollLeft: maxscroll
		    }, speed, "linear");
		});

		$(elm).mouseout(function() {
		    $(this).stop();
		    $(this).addClass("ellipsis");
		    $(this).animate({
		        scrollLeft: 0
		    }, 'slow');
		});

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnTextScroll", err: e });
    }
}

GSH.Misc.fnGVal = function(params) {
	try {
		var strKey		=	params.key;
		var strData		=	params.data;
		var chrSplitA	=	(params.splitA	!=	undefined	&&	params.splitA	!=	"") ? params.splitA :	"|" ;
		var chrSplitB	=	(params.splitB	!=	undefined	&&	params.splitB	!=	"") ? params.splitB :	"=" ;
		var defVal		=	(params.defVal	!=	undefined	&&	params.defVal	!=	"") ? params.defVal :	"" ;

		var arrData		=	strData.split(chrSplitA);
		var strValue	=	"";

		for(var i = 0; i < arrData.length; i++) {
			var arrValue = arrData[i].split(chrSplitB);
			if(arrValue[0].toUpperCase() == strKey.toUpperCase()) {
				strValue = arrValue[1];
				break;
			}
		}
		return (strValue != "") ? strValue : defVal ;
	} catch(e) {
		GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGVal", err: e });
	}
}

GSH.Misc.fnShowHDDrop = function(id){
    try {
        GSH.Misc.fnHideHDDrop();
        var div     = id;
        if($("#"+ div).css("display") == "block") {
            GSH.Misc.fnHideHDDrop();
            $("[data-div='"+ div +"']").removeClass("_selected");
        } else {
            $("#"+ div).fadeIn('fast');
            $("[data-div='"+ div +"']").addClass("_selected");
        }
    } catch(e){
        console.log("In Error function", e);
    }
}

GSH.Misc.fnHideHDDrop = function(){
    try {
    	$("[data-div]").removeClass("_selected");
        $("div[data-dropdown='1']").fadeOut('fast');
    } catch(e){
        console.log("In Error function", e);
    }
}


$(document).keyup(function(e) {
     if (e.keyCode == 27) { // escape key maps to keycode `27`

        // Added for nav dropdown
        if($("div[data-dropdown='1']").is(":visible")){
            GSH.Misc.fnHideHDDrop();
        }
    }
});


GSH.Misc.fnGPipeDelimitedString = function(obj) {
	try {
		var str = [];
		for (var key in obj) {
		    if (obj.hasOwnProperty(key)) {
		        str.push(key + "=" + obj[key]);
		    }
		}

		if (str.length == 0) {
		    str = "";
		} else {
		    str = "|" + str.join("|") + "|";
		}
		return str;
	} catch(e) {
		GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGPipeDelimitedString", fnParams: obj, err: e });
	}
}


GSH.Misc.fnBusy = function(bln, obj) {
	try {
		if(bln) {

            $("#dText").html("Loading...");

            if(typeof obj !== "undefined" && obj.message != "") {
                
                /* Set Custom message */
                var _text = obj.message;
                $("#dText").html(_text);

            }

            /* Show dBusy */
            $("#dBusy").show();

        } else {            
            $("#dBusy").hide();
        }
		
	} catch(e) {
		GSH.Misc.fnErr({ fnName: "GSH.Misc.fnBusy", fnParams: element, err: e });
	}
}

GSH.Misc.fnBusyMsg = function(bln,msg){
	try{
		var strLoadHtml = "";
		if($(".divBusy").length < 1){
			strLoadHtml += '<div class="divBusy">';
				strLoadHtml += '<div class="__table">';
					strLoadHtml += '<div data-busy-text>Loading...</div>';
				strLoadHtml += '</div>';
			strLoadHtml += '</div>';
			$('body').append(strLoadHtml);
		}

		$("[data-busy-text]").text(msg);
		if(bln){
			$(".divBusy").show();
		} else {
			$(".divBusy").hide();
		}
	} catch(e){
		GSH.Misc.fnErr({ fnName: "GSH.Misc.fnBusy", err : e });
	}
}

GSH.Misc.fnErr = function(params) {
	try {

		var fName 	= (typeof params.fnName !== "undefined" && params.fnName 	!= "") ? params.fnName : "" ;
		var err 	= (typeof params.err 	!== "undefined" && params.err 		!= "") ? params.err : "" ;

	} catch(e) {
		console.log("In Error function");
	}
}

GSH.Misc.fnCussMessDisp = function(params) {
    try {
        alert(params.mess);
        var dId     = (typeof params.divId  !== "undefined" && params.divId != "") ? params.divId   : "" ;
        var type    = (typeof params.type   !== "undefined" && params.type  != "") ? params.type    : "" ;
        var mess    = (typeof params.mess   !== "undefined" && params.mess  != "") ? params.mess    : "" ;
        var elem    = $("#"+dId).find(".frm-msg");

        elem.addClass("_"+type).text(mess).show();

        setTimeout(function(){
            if($("#"+dId).find("._ferror").length < 1){
                elem.removeClass("_"+type).text("").hide();
            }
        }, 2000);

    } catch(e) {
        GSH.Misc.fnErr({ fnName : "GSH.Misc.fnCussMessDisp", err: e });
    }
}

GSH.Misc.fnCusMessModal = function(id, msg, img) {
    try {
        var _id     = id;
        var _msg    = msg;

        $("#"+ id +" .__text").html(msg);
        
        if(id == "mdError")
            $("#"+ id +" .__img").html("<img src='/assets/img/msg/error.png' alt='GetSetHome - Message'>");
        else
            $("#"+ id +" .__img").html("<img src='/assets/img/msg/success.png' alt='GetSetHome - Message'>");

        if(img)
            $("#"+ id +" .__img").html("<img src='/assets/img/msg/"+ img +".png' alt='GetSetHome - Message'>");

        GSH.Misc.modal(id, 1);

    } catch(e){
        GSH.Misc.fnErr({ fnName : "GSH.Misc.fnCusMessModal", err: e });
    }
}


GSH.Misc.fnCussMessDiv = function(params) {
	try {

		var dId 	= (typeof params.divId 	!== "undefined" && params.divId != "") ? params.divId 	: "" ;
		var mess 	= (typeof params.mess 	!== "undefined" && params.mess 	!= "") ? params.mess 	: "" ;

		var divId = dId + "Txt";

		console.log(params);

		$("[data-group=dAlertMessage]").hide();

		// Add text to the div and then show
		$("#"+divId).html(mess);
		$("[data-id=" + dId + "]").show();
		window.scrollTo(0, 0);
		GSH.Misc.fnBusyMsg(0);


	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Misc.fnCussMessDiv", err: e });
	}
}


GSH.Misc.fnUrlName = function(strUrl) {
	try {
		strUrl = strUrl.replace(/[^a-zA-Z 0-9]+/g, "");
		strUrl = strUrl.replace(new RegExp(" ", "gi"), "-");
		strUrl = strUrl.replace(/-+/gi, "-");
		return strUrl.toLowerCase();
	} catch(e) {
		GSH.Misc.fnErr({ fnName: "GSH.Misc.fnUrlName", fnParams: strUrl, err: e });
	}
}

GSH.Misc.fnGATracker = function (param){
	try{
		var page 	=	location.pathname.replace(/\//g, '');
		var pgName 	= 	(page == "")? "home": page;

		var loc 	= (param.location != "")? "-" + param.location : "";
		var act		= (param.action != "")? "-" + param.action : "";
		var code = pgName + loc + act;
		// _gaq.push(['_trackPageview', code]);

		if (typeof(ga) !== "undefined") {
			ga('send', 'pageview', code);
		}

		if (typeof(wzrk_pushSiteEvent) != "undefined") {
			wzrk_pushSiteEvent(code);
		}
	}catch(e){
		GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGATracker", fnParams: arguments, err: e });
	}
}

GSH.Misc.fnBrowsVer = function () {
	try {
		rv	=	-1;
		if (navigator.appName == 'Microsoft Internet Explorer') {
			var ua	=	navigator.userAgent;
			var re	=	new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
			if (re.exec(ua) != null) {
				rv	=	parseFloat(RegExp.$1);
			}
		}
		else {
			rv	=	999.0;
		}
		return rv;
	} catch(e) {
		GSH.Misc.fnErr({"fnName": "GSH.Misc.fnBrowsVer", "err": e});
	}
}

GSH.Misc.fnCapitalName = function(name) {
	try{
	    var a = $.trim(name).split(" ");
	    var b = '';
	    for(var i = 0;  i<a.length;i++){
	         if(a[i] != ''){
	             b += (a[i].substr(0,1).toUpperCase()+a[i].substr(1,a[i].length))+" ";
	         }
	    }
	    return b;
	}catch(e) {
		GSH.Misc.fnErr({"fnName": "GSH.Misc.fnCapitalName", "err": e});
	}
}

GSH.Misc.fnBtnProcessing = function(btnId, bln) {
	try {
		if(bln) {
			$('#'+btnId).addClass('_processing');

		} else {
			$('#'+btnId).removeClass('_processing');

		}
	} catch(e) {
		GSH.Misc.fnErr({ fnName: "GSH.Misc.fnBtnProcessing", fnParams: btnId+" "+bln, "err": e });
	}
}

GSH.Misc.fnGoTo = function (strUrl) {
	try {
	    setTimeout("window.location.href='" +  strUrl + "'", 0);
	} catch (e) {
		GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGoTo", fnParams: arguments, err: e });
	}
}

GSH.Misc.IsValidDate = function(i, h, j) {
	try{
	    var g = h + "/" + i + "/" + j;
	    var f = new Date(g);
	    if (f.getDate() != i) {
	        return false;
	    } else {
	        if (f.getMonth() != h - 1) {
	            return false;
	        } else {
	            if (f.getFullYear() != j) {
	                return false;
	            }
	        }
	    }
	    return true;
	} catch(e) {
		GSH.Misc.fnErr({ fnName: "GSH.Misc.IsValidDate", fnParams: i + " " + h + " " + j, err: e });
	}
}

GSH.Misc.fnGQS = function (strKey, defVal) {
	try {
		var defVal	=	(defVal != undefined) ? defVal : "" ;
		var q = window.location.search.substring(1);
		var v = q.split("&");
		for (var i = 0; i < v.length; i++) {
			var p = v[i].split("=");
			if (p[0] == strKey) {
				return p[1];
			}
		}
		return defVal;
	} catch(e) {
		GSH.Misc.fnErr({ fnName: "misc.js - GSH.Misc.fnGQS", fnParams: arguments, err: e });
	}
}


/*===========================================
=            VALIDATOR FUNCTIONS            =
===========================================*/


GSH.Validate.name = function(strName) {
	try {
		
		var regxOnlyCharSpace = /[a-zA-Z ]+/;
		if(regxOnlyCharSpace.test(strName)) {			
			return true;
		} else {
			return false;
		}

	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.name", err : e });
	}
}


GSH.Validate.mobile = function(strMobile) {
	try {
		
		var regxMobile = /([0-9]){10}/g;
		if(regxMobile.test(strMobile)) {			
			return true;
		} else {
			return false;
		}

	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.mobile", err : e });
	}
}

GSH.Validate.email = function(strEmail) {
	try {
		
		var regxEmail = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if(regxEmail.test(strEmail)) {			
			return true;
		} else {
			return false;
		}
	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.email", err : e });
	}
}


GSH.Validate.comments = function(strText) {
	try {
		var regxCmt = /^[a-zA-Z\d\_.,!&@+():;#£$*?\/%^+={}"'\<`~|\s]+$/g;
		if(regxCmt.test(strText)) {			
			return true;
		} else {
			return false;
		}
	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.comments", err : e });
	}
}

GSH.Validate.ifscCode = function(strText) {
	try {
		var regx = /^[A-Za-z]{4}\d{7}$/g;
		if(regx.test(strText)) {			
			return true;
		} else {
			return false;
		}
	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.ifscCode", err : e });
	}
}

GSH.Validate.bankAcNo = function(strText) {
	try {
		var regx = /^([0-9]{10})|([0-9]{2}-[0-9]{3}-[0-9]{6})$/;
		if(regx.test(strText)) {			
			return true;
		} else {
			return false;
		}
	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.ifscCode", err : e });
	}
}

/*=====  End of VALIDATOR FUNCTIONS  ======*/


/*
	Function to pass data to Wizrocker and KissMetrics

	sources		:	should be ["WR", "KM"]
	eventName	:	should be the event name which is specified in the current site's calling function/ excel sheet
	dataObject	:	is an object ({}) which will contain the key value to be sent along with the eventName

	Example:

	GSH.Misc.fnPushEventDataToAnalytics(["WR", "KM"], "Click on show time", {
		"Venue Code": "ABCD",
		"Session ID": "12345",
		"App code": "ABCDE"
	});

	PS:
		The eventName and dataObject will change as required. The above one is just an example.
*/


/*========= Calculate Date range =======*/
GSH.Misc.fnCalculateEndDate = function(objConfig) {
    try {

        var arrReturnData = [];
        var day     = objConfig.day;
        var month   = objConfig.month;
        var year    = objConfig.year;

        var tenure  = objConfig.tenure;
        var bucket  = objConfig.bucket;

        month       = (month - 1);

        var strDate = new Date(year, month, day);
        

        var month_count = (tenure / bucket);

        var tenureEnddate = '';

        var endDate = new Date ( new Date (strDate.setMonth(strDate.getMonth()+month_count)));
        endDate = new Date ( new Date (endDate.setDate(endDate.getDate()-1)));

        arrReturnData.push(""+endDate);

        if(bucket > 1) {
            for(var i=1; i<bucket; i++) {
                endDate = new Date ( new Date (endDate.setMonth(endDate.getMonth()+month_count)));
                 arrReturnData.push(""+endDate);
            }

        }

        return arrReturnData;

    } catch(e) {
        GSH.Misc.fnErr({ fnName : "owner.fnCalculateEndDate", err : e});
    }
}

GSH.Misc.fnConvertDate = function(inputFormat) {
    try {
        function pad(s) { return (s < 10) ? '0' + s : s; }
        var d = new Date(inputFormat);
        return [pad(d.getDate()), pad(d.getMonth()+1), d.getFullYear()].join('/');
    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnConvertDate", err: e });
    }
}

GSH.Misc.fnDateName = function(inputFormat){
    try {
        var dateValue   = Date(inputFormat);
        var month       = dateValue.substring(4,7);
        var date        = dateValue.substring(8,10);
        var year        = dateValue.substring(20,24);
        var finaldateString = date+"-"+month+"-"+year;
        return finaldateString;
    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnDateName", err: e });
    }   
}

GSH.Misc.fnDateFormat = function(inputFormat){
    try {
        var inDate  = inputFormat.split(" ")[0];
        var myDate  = new Date(Date.parse(inDate));
        myDate      = myDate.format('M jS, Y');
        return myDate;
    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnDateFormat", err: e });
    }
}

GSH.Misc.fnDateFormed = function(inputFormat){
    try {
        
        var monthNames = [
        "January", "February", "March",
        "April", "May", "June", "July",
        "August", "September", "October",
        "November", "December"
      ];

      var date          = new Date(inputFormat);
      var day           = date.getDate();
      var monthIndex    = date.getMonth();
      var year          = date.getFullYear();

      return day + ' ' + monthNames[monthIndex] + ' ' + year;

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnDateFormed", err: e });
    }
}

GSH.Misc.fnCalculateAge = function(inputFormat){ // birthday is a date
    try {
        var inputFormat = new Date(inputFormat);
        var ageDifMs    = Date.now() - inputFormat.getTime();
        var ageDate     = new Date(ageDifMs); // miliseconds from epoch
        return Math.abs(ageDate.getUTCFullYear() - 1970);

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnDateFormed", err: e });
    }
}

GSH.Misc.fnAddSubDate = function(params){
    try {

        var _date       = (typeof params.date       !== "undefined" && params.date      != "") ? params.date        : "" ;
        var _type       = (typeof params.type       !== "undefined" && params.type      != "") ? params.type        : "" ;
        var _action     = (typeof params.action     !== "undefined" && params.action    != "") ? params.action      : "" ;
        var _add        = (typeof params.add        !== "undefined" && params.add       != "") ? params.add         : "" ;
        var _actDate    = new Date(_date);
        var _resultDate = "";

        if(_type == "days"){
            if(_action == "add")
                _resultDate  = _actDate.setDate(_actDate.getDate()+parseInt(_add));
            else
                _resultDate  = _actDate.setDate(_actDate.getDate()-parseInt(_add));
        }
        if(_type == "months"){
            if(_action == "add")
                _resultDate  = _actDate.setMonth(_actDate.getMonth()+parseInt(_add));
            else
                _resultDate  = _actDate.setMonth(_actDate.getMonth()-parseInt(_add));
        }
        if(_type == "years"){
            if(_action == "add")
                _resultDate  = _actDate.setFullYear(_actDate.getFullYear()+parseInt(_add));
            else
                _resultDate  = _actDate.setFullYear(_actDate.getFullYear()-parseInt(_add));
        }

        _resultDate         = new Date(_resultDate);
        var _month          = _resultDate.getMonth()+1;
        _month              = (_month < 10 ? "0"+_month : _month);
        var _day            = (_resultDate.getDate() < 10 ? "0"+_resultDate.getDate() : _resultDate.getDate());
        _resultDate         =  _resultDate.getFullYear() +'-'+ _month +'-'+ _day;

        return _resultDate;

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnAddSubDate", err: e });
    }
}

GSH.Misc.fnIsLeapYear = function(year) { 
    try {
        return (((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0)); 
    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnIsLeapYear", err: e });
    }
}

GSH.Misc.fnGetDaysInMonth = function(year, month) { 
    try {
        return [31, (GSH.Misc.fnIsLeapYear(year) ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month];
    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGetDaysInMonth", err: e });
    }
}

GSH.Misc.fnGetRandomColor = function() {
    try {
        var letters = 'BCDEF'.split('');
        var color   = '#';
        for (var i = 0; i < 6; i++ ) {
            color += letters[Math.floor(Math.random() * letters.length)];
        }
        return color;
    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGetRandomColor", err: e });
    }
}


GSH.Misc.fnMakeAvailableDate = function(inputDate){
    try {
        
        function pad(s) { return (s < 10) ? '0' + s : s; }

        var availableFrom   = new Date(inputDate);
        availableFrom       = new Date(availableFrom);
        availableFrom.setDate(availableFrom.getDate() + 1);

        var dateValue       = new Date(availableFrom);
        return [dateValue.getFullYear(), pad(dateValue.getMonth()+1), pad(dateValue.getDate())].join('-');

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnMakeAvailableDate", err: e });
    }
}

GSH.Misc.fnMakeShortUrl = function(params, callback){
    try {

        var _url        = ( typeof params.url           !== "undefined" && params.url           != "" )   ? params.url              :   '';
        var _type       = ( typeof params.type          !== "undefined" && params.type          != "" )   ? params.type             :   '';

        GSH.Misc.fnBusyMsg(1, "Generating short link...");
        
        GSH.Misc.fnAjax({
            url: GSH.AdminAPI,
            data: {
                "cmd"       : "GENERATESHORTURL",
                "url_type"  : _type,
                "longUrl"   : _url
            },
            success: function(data) {
                GSH.Misc.fnBusyMsg(0);
                callback(data);
            },
            error: function(xhr, status, err) {
                GSH.Misc.fnBusyMsg(0);
                console.log("Error", err);
                alert("something went wrong while adding a tenant");
            }
        });
    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnMakeShortUrl", err: e });
    }
}

GSH.Misc.fnGenerateExcel = function(arr, filename){
    try {

        var $frm        = $('#generateExcel');
        var _strHtml    = "";

        if($frm.length < 1){
            _strHtml += '<form name="generateExcel" id="generateExcel" action="" method="POST" target="_blank">';
                _strHtml += '<input type="hidden" value="GENERATEEXCEL" name="cmd">';
                _strHtml += '<input type="hidden" id="excelArray" name="array">';
                _strHtml += '<input type="hidden" id="excelFilename" name="filename">';
            _strHtml += '</form>';
            $("body").append(_strHtml);
        }

        $frm.find("#excelArray").val(arr);
        $frm.find("#excelFilename").val(filename);

        $frm.attr('action', location.protocol + "//" + location.host + '/admin/dompdf/excel/');
        $frm.submit();

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnGenerateExcel", err: e });
    }
}

GSH.Misc.fnRemoveDuplicate = function(arr) {
    try{
        
		var arrOld = arr;
		var arrNew = [];

		$.each(arrOld, function(i, el){
		    if($.inArray(el, arrNew) === -1) arrNew.push(el);
		});

		return arrNew;

    } catch(e){
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnRemoveDuplicate", fnParams: arr, err: e });
    }
}

GSH.Misc.fnRemoveDuplicateKey = function(arr, prop) {
	try{
		var new_arr = [];
		var lookup  = {};

		for (var i in arr) {
			lookup[arr[i][prop]] = arr[i];
		}

		for (i in lookup) {
			new_arr.push(lookup[i]);
		}

		return new_arr;

    } catch(e){
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnRemoveDuplicateKey", fnParams: arr, err: e });
    }
}

GSH.Misc.modal = function(id, bln) {
    try {

        if(bln) {
            GSH.Modal.fnShowModal(id);
        } else {
            GSH.Modal.fnHideModal();
        }

    } catch(e) {
        console.log("In Error function", e);
    }
}

GSH.Misc.fnViewTenant = function(id, page) {
    try {
        var _strHtml = "";
        if($("#viewTenant").length < 1){
            _strHtml += '<form name="viewTenant" id="viewTenant" action="" method="POST" target="_blank">';
                _strHtml += '<input type="hidden" value="" id="view_tenant_id" name="id">';
            _strHtml += '</form>';
            $("body").append(_strHtml);
        }

        var $frm = $('#viewTenant');
        $("#view_tenant_id").val(id);
        $frm.attr('target', '_blank');
        if(page == "ledger")
          $frm.attr('action', location.protocol + "//" + location.host + '/admin/tenant/ledger');
        else
          $frm.attr('action', location.protocol + "//" + location.host + '/admin/tenant/');

        $frm.submit();

    } catch(e) {
        GSH.Misc.fnErr({ fnName : "GSH.Misc.fnViewTenant", err : e });
    }
}

GSH.Misc.fnViewTenant = function(id, page) {
    try {
        var _strHtml = "";
        if($("#viewTenant").length < 1){
            _strHtml += '<form name="viewTenant" id="viewTenant" action="" method="POST" target="_blank">';
                _strHtml += '<input type="hidden" value="" id="view_tenant_id" name="id">';
            _strHtml += '</form>';
            $("body").append(_strHtml);
        }

        var $frm = $('#viewTenant');
        $("#view_tenant_id").val(id);
        $frm.attr('target', '_blank');
        if(page == "ledger")
          $frm.attr('action', location.protocol + "//" + location.host + '/admin/tenant/ledger');
        else
          $frm.attr('action', location.protocol + "//" + location.host + '/admin/tenant/');

        $frm.submit();

    } catch(e) {
        GSH.Misc.fnErr({ fnName : "GSH.Misc.fnViewTenant", err : e });
    }
}

GSH.Misc.fnViewEnquiry = function(id,mobile,status) {
    try {

        var _strHtml    = "";
        var $form       = $("#viewLead");

        if($form.length < 1){
            _strHtml += '<form name="viewLead" id="viewLead" action="" method="POST" target="_blank">';
                _strHtml += '<input type="hidden" id="enqid" name="id">';
                _strHtml += '<input type="hidden" id="enqmobile" name="mobile">';
                _strHtml += '<input type="hidden" id="enqStatus" name="status">';
            _strHtml += '</form>';
            $("body").append(_strHtml);
        }
        
        $form.find("#enqid").val(id);
        $form.find("#enqmobile").val(mobile);
        $form.find("#enqStatus").val(status);

        $form.attr('target', '_blank');
        $form.attr('action', location.protocol + "//" + location.host + '/admin/sales/');
        $form.submit();

    } catch(e) {
        GSH.Misc.fnErr({ fnName : "page.fnViewEnquiry", err : e });
    }
}

GSH.Misc.fnViewProperty = function(id, page) {
    try {
        var _strHtml = "";
        if($("#viewProperty").length < 1){
            _strHtml += '<form name="viewProperty" id="viewProperty" action="" method="POST" target="_blank">';
                _strHtml += '<input type="hidden" value="" id="view_property_id" name="id">';
            _strHtml += '</form>';
            $("body").append(_strHtml);
        }

        var $frm = $('#viewProperty');
        $("#view_property_id").val(id);
        $frm.attr('target', '_blank');
        if(page == "insight")
          $frm.attr('action', location.protocol + "//" + location.host + '/admin/property/prop-wise-insight');
        else
          $frm.attr('action', location.protocol + "//" + location.host + '/admin/property/create-property');

        $frm.submit();

    } catch(e) {
        GSH.Misc.fnErr({ fnName : "GSH.Misc.fnViewProperty", err : e });
    }
}


GSH.Misc.fnViewOwner = function(id, city, property_id) {
	try {

		var _strHtml = "";
		if($("#viewOwner").length < 1){
			_strHtml += '<form name="viewOwner" id="viewOwner" action="" method="POST" target="_blank">';
				_strHtml += '<input type="hidden" value="" id="view_owner_id" name="owner_id">';
				_strHtml += '<input type="hidden" value="" id="view_city_id" name="city">';
				_strHtml += '<input type="hidden" value="" id="view_property_id" name="property_id">';
			_strHtml += '</form>';
			$("body").append(_strHtml);
		}

		var $frm = $('#viewOwner');
		$("#view_owner_id").val(id);
		$("#view_city_id").val(city);
		$("#view_property_id").val(property_id);
		$frm.attr('target', '_blank');
		$frm.attr('action', location.protocol + "//" + location.host + '/admin/owner/');

		$frm.submit();

	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Misc.fnViewOwner", err : e });
	}
}

GSH.Misc.fnAddToBlackList = function() {
	try {
		var _id 	= $("#inpBlackListTenant").val();
		var _com 	= $("#inpBlackListComment").val();

		if(_id == ""){
			GSH.Misc.fnAndroidErr("Tenant Id is missing");
            return;
		}
		if(_com == ""){
			GSH.Misc.fnAndroidErr("Comment is missing");
            return;
		}

		GSH.Misc.fnBusyMsg(1, "Blacklisting...");

		GSH.Misc.fnAjax({
        	url		: '/admin/api/',
	        data	: {
	        	cmd 		: 'BLACKLISTTENANT',
				tenant_id 	: _id,
				comments 	: _com
	        },
	        success	: function (data) {
	        	GSH.Misc.fnBusyMsg(0);

	        	data = JSON.parse(data);
	        	
	        	GSH.Modal.fnHideModal("mdAddToBlackList");

	        	if(data.status == "true"){
                    if(ledger){
                    	ledger.fnLoad();
                    } else {
		        		GSH.Misc.fnAndroidErr("Updated Successfully");
		        		window.location.reload();
                    }
	        	} else {
	        		GSH.Misc.fnAndroidErr(data.error.DisplayMessage);
	        	}
	        }, 
	        error 	: function(xhr, status, err) {
	        	console.log("Error while sending "+ _type +"," + err);
	        }
    	});

	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Misc.fnAddToBlackList", err : e });
	}
}

GSH.Misc.fnDisplayOTPTimer = function(minutes){
    try{
        var otpTimer;
        var totalMinutes    = 60*minutes;
        
        clearInterval(GSH.OTPTimer);

        GSH.OTPTimer        = setInterval(function(){

                                totalMinutes = totalMinutes - 1; 

                                if (totalMinutes == -1) {
                                    $("[data-otptimer]").html("Sorry!, time up");
                                    clearInterval(otpTimer);
                                    return;
                                }

                                var _otpSeconds = totalMinutes % 60;
                                var _otpMinutes = Math.floor(totalMinutes / 60);
                                
                                _otpMinutes     %= 60;
                                $("[data-otptimer]").removeClass("_info").addClass("_warning");
                                $("[data-otptimer]").html("");
                                $("[data-otptimer]").html(_otpMinutes + ":" + _otpSeconds + " left");

                            }, 1000);

    } catch(e){
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnDisplayOTPTimer", fnParams: minutes, err: e });
    }
}

GSH.Misc.arrValue = function(val) {
    try {
    	if(val != null && val != undefined && val != "")
    		return true;
    	else
    		return false;

    } catch(e) {
        console.log("In Error function", e);
    }
}

GSH.Misc.fnCheckToday = function(val) {
    try {
            var _inputDate   = new Date(val);
            var _todaysDate  = new Date();

            if(_inputDate.setHours(0,0,0,0) == _todaysDate.setHours(0,0,0,0))
                return true;
            else
                return false;
            
    } catch(e) {
        console.log("In Error function", e);
    }
}

GSH.Misc.fnPushEventDataToAnalytics = function (sources, eventName, dataObject, dataObjectGA) {
	try {

		var dataObject_WR = $.extend(true, {}, dataObject);
		var dataObject_KM = $.extend(true, {}, dataObject);
		var dataObject_GA = $.extend(true, {}, dataObjectGA);

		if ($.inArray("WR", sources) != -1) {
			if (typeof(wizrocket) !== "undefined" && typeof(wizrocket.event) !== "undefined") {
				wizrocket.event.push(eventName, dataObject_WR);
			}
		}

		if ($.inArray("KM", sources) != -1) {
			if (typeof(_kmq) !== "undefined") {
				_kmq.push(['record', eventName, dataObject_KM]);
			}
		}

		if ($.inArray("GA", sources) != -1 || $.inArray("GTM", sources) != -1) {
			if (typeof(dataLayer) !== "undefined") {
				dataLayer.push(dataObject_GA);
			}
		}

	} catch (e) {
		GSH.Misc.fnErr({ fnName: "misc.js - GSH.Misc.fnPushEventDataToAnalytics", fnParams: arguments, err: e });
	}
};

GSH.Misc.fnisOdd = function(num) {
    try{
        return num % 2;
    } catch(e){
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnisOdd", fnParams: num, err: e });
    }
}

GSH.Misc.fnDisplayRupees = function(num) {
    try{

		var x 				= parseInt(num);
		x    				= x.toString();
		var lastThree 		= x.substring(x.length-3);
		var otherNumbers 	= x.substring(0,x.length-3);

		if(otherNumbers != '')
		    lastThree = ',' + lastThree;

		var res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
		return res;

    } catch(e){
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnDisplayRupees", fnParams: num, err: e });
    }
}

GSH.Misc.fnPushNotification = function(params) {
    try{
    		var _icon 	= params.icon;
    		var _title 	= params.title;
    		var _body 	= params.body;
    		var _link 	= params.link;
		
		  	if (Notification.permission !== "granted")
		    	Notification.requestPermission();
		  	else {
		    	var notification = new Notification(_title, {
		      		icon: _icon,
		      		body: _body,
		      		requireInteraction: true
		    	});
			    notification.onclick = function () {
			      	window.open(_link);
			    };
		  }

    } catch(e){
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnDisplayRupees", fnParams: num, err: e });
    }
}

GSH.Misc.fnMakeUserInfoGlobal = function(strData) {
    try {
        if(GSH.Misc.arrValue(strData)){
            var arrUserInfo = strData.split('|');

            for (var i = 0; i < arrUserInfo.length; i++) {
                if(GSH.Misc.arrValue(arrUserInfo[i])){
                    var arrCur  = arrUserInfo[i].split("=");
                    var _key    = arrCur[0];
                    var _val    = arrCur[1];

                    if(_key != "" && _key != undefined){
                        GSH.UserInfo[_key] = [];
                        GSH.UserInfo[_key] = _val;
                    }
                }
            }
        }

    } catch(e) {
        GSH.Misc.fnErr({ fnName: "GSH.Misc.fnMakeUserInfoGlobal", fnParams: strData, err: e });
    }
}

/* Calling modal plugin on document ready */
$(document).ready(function() {
	$("body").modal();

    $("[data-search-box]").on("focus", function(){
        $(this).val("");
    });
    
	Notification.requestPermission();

	if(keep.get({ name : 'ld'}) != ""){
		GSH.Misc.fnGetCRMUserInfo();
	}

	$("[data-action=Logout]").on("click", function(){
		GSH.Misc.fnBusyMsg(1,'Logging you out...');
        setTimeout(function(){
            GSH.Misc.fnLogout();
        }, 300);
	});

	$("[data-nav]").on("click", function(){
		var _elem = $(this).attr("data-module");
		$("[data-nav]").removeClass("_active");
		
		$("[data-subnav]").slideUp();
		if($("[data-subnav='"+ _elem +"']").css("display") == "block"){
			$(this).removeClass("_active");
			$("[data-subnav='"+ _elem +"']").slideUp();
		} else {
			$(this).addClass("_active");
			$("[data-subnav='"+ _elem +"']").slideDown();
		}
	});

	$("[data='parent-nav']").on("click", function(){
		var $elm = $(this).next(".sub-nav");
		$("[data='child-nav']").slideUp();
		if($elm.css("display") == "block"){
			$elm.slideUp();
			$(this).removeClass("_active");
		} else {
			$elm.slideDown();
			$(this).addClass("_active");
		}
	});

    if(GSH.Device == "Mobile"){
        $(".material-design-hamburger").on("click", function() {
            if($(".crm-topsection").hasClass("menu--on")){
                $("[data-subnav]").slideUp();
                $(".crm-topsection").removeClass("menu--on");
                $(".material-design-hamburger__layer").removeClass("material-design-hamburger__icon--to-arrow");
            } else {
                $(".crm-topsection").addClass("menu--on");
                $(".material-design-hamburger__layer").addClass("material-design-hamburger__icon--to-arrow");
            }
        });
    } else {
        $(".crm-topsection, .material-design-hamburger").on( "mouseenter", function() {
            $(".crm-topsection").addClass("menu--on");
            $(".material-design-hamburger__layer").addClass("material-design-hamburger__icon--to-arrow");
        }).on( "mouseleave", function() {
            $("[data-subnav]").slideUp();
            $(".crm-topsection").removeClass("menu--on");
            $(".material-design-hamburger__layer").removeClass("material-design-hamburger__icon--to-arrow");
        });
    }

	$(".crm-topsection [data-module]").each(function(key, val){
		var _module = $(val).data("module");
		if($("[data-subnav='"+ _module +"']").length < 1)
			$(val).hide();
		else
			$(val).show();
	});
	
	jQuery.expr[':'].contains = function(a, i, m) {
	  	return jQuery(a).text().toUpperCase().indexOf(m[3].toUpperCase()) >= 0;
	};
});

$(document).keyup(function(e) {
     if (e.keyCode == 27) { // escape key maps to keycode `27`

        if($(".modal-wrapper").is(":visible")){
            GSH.Misc.modal();
        }
    }
});
