GSH.Validate.name = function(strName) {
	try {
		
		var regxOnlyCharSpace = /[a-zA-Z ]+/;
		if(regxOnlyCharSpace.test(strName)) {			
			return true;
		} else {
			return false;
		}

	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.name", err : e });
	}
}


GSH.Validate.mobile = function(strMobile) {
	try {
		
		var regxMobile = /([0-9]){10}/g;
		if(regxMobile.test(strMobile)) {		
			return true;
		} else {
			return false;
		}

	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.mobile", err : e });
	}
}

GSH.Validate.email = function(strEmail) {
	try {
		
		var regxEmail = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if(regxEmail.test(strEmail)) {			
			return true;
		} else {
			return false;
		}
	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.email", err : e });
	}
}

GSH.Validate.comments = function(strText) {
	try {
		var regxCmt = /^[a-zA-Z\d\_.,!&@+():;#£$*?\/%^+={}"'\<`~|\s]+$/g;
		if(regxCmt.test(strText)) {			
			return true;
		} else {
			return false;
		}
	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.comments", err : e });
	}
}

GSH.Validate.ifscCode = function(strText) {
	try {
		var regx = /^[A-Za-z]{4}\d{7}$/g;
		if(regx.test(strText)) {			
			return true;
		} else {
			return false;
		}
	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.ifscCode", err : e });
	}
}

GSH.Validate.bankAcNo = function(strText) {
	try {
		var regx = /^([0-9]{10})|([0-9]{2}-[0-9]{3}-[0-9]{6})$/;
		if(regx.test(strText)) {			
			return true;
		} else {
			return false;
		}
	} catch(e) {
		GSH.Misc.fnErr({ fnName : "GSH.Validate.ifscCode", err : e });
	}
}